export interface OutputTemplate { [key: string]: any }

export interface PromptEntry {
  id: string
  team: string
  name: string
  description: string
  language: string
  version: string
  input_vars: string[]
  prompt: string
  output_template: OutputTemplate
  tags: string[]
}

export interface ToolsManifest {
  tools: Array<{
    type: "function",
    function: {
      name: string
      description: string
      parameters: {
        type: "object",
        properties: Record<string, { type: string; description?: string }>
        required?: string[]
      }
      ["x-output-template"]?: any
      ["x-tags"]?: string[]
      ["x-language"]?: string
      ["x-version"]?: string
    }
  }>
}
