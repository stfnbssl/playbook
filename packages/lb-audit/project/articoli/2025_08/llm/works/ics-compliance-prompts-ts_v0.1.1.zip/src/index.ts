import promptsData from "../data/prompts.json" assert { type: "json" }
import manifestData from "../data/manifest.json" assert { type: "json" }
import type { PromptEntry, ToolsManifest } from "./types"

export const prompts: PromptEntry[] = promptsData as PromptEntry[]
export const toolsManifest: ToolsManifest = manifestData as ToolsManifest

export type { PromptEntry, ToolsManifest } from "./types"

export function getPrompt(id: string): PromptEntry | undefined {
  return prompts.find(p => p.id === id)
}

export function listPromptsByTeam(team: string): PromptEntry[] {
  return prompts.filter(p => p.team.toLowerCase() === team.toLowerCase())
}

export function asTools() {
  return toolsManifest.tools
}
