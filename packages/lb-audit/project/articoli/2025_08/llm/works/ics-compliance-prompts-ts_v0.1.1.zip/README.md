# ics-compliance-prompts

Prompt library e manifest strumenti per progetti ICS/OT (IEC 62443, RED, CRA).

## Installazione (locale)
1. Scarica l'archivio e scompattalo.
2. Nel progetto: `npm i ./ics-compliance-prompts-ts`

## Utilizzo
ESM:
```ts
import { prompts, getPrompt, listPromptsByTeam, toolsManifest, asTools } from "ics-compliance-prompts"

console.log(prompts.length)
const triager = getPrompt("compliance-applicability-conformity-path")
const onlyProduct = listPromptsByTeam("Prodotto")

// Passa asTools() direttamente al campo 'tools' dell'API OpenAI
const tools = asTools()
```

CommonJS:
```js
const { prompts, getPrompt, listPromptsByTeam, toolsManifest, asTools } = require("ics-compliance-prompts")
```

## Esportazioni
- `prompts` — array di prompt con metadati.
- `toolsManifest` — schema `tools[]` pronto per OpenAI Functions.
- Helpers: `getPrompt(id)`, `listPromptsByTeam(team)`, `asTools()`.

## Dati inclusi
- `data/prompts.json`
- `data/manifest.json`

## Tipo pacchetto
- Dual module (ESM + CJS), TypeScript typings inclusi.
